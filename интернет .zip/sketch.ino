#include "WiFi.h"
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Настройка экрана
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Настройка кнопки
const int BUTTON_PIN = 4;

int numberOfNetworks = 0; // Сколько сетей нашли всего
int currentNetworkIndex = 0; // Какую сеть сейчас показываем
unsigned long lastScanTime = 0; // Время последнего сканирования
const unsigned long SCAN_INTERVAL = 30000; // Авто-сканирование каждые 30 секунд

// Функция для запуска сканирования сетей
void scanWiFi() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Scanning Wi-Fi...");
  Serial.println("Сканирование запущено...");

  numberOfNetworks = WiFi.scanNetworks();
  currentNetworkIndex = 0; // Сбрасываем индекс на первую сеть

  lcd.clear();
  if (numberOfNetworks == 0) {
    lcd.print("No nets found");
    Serial.println("Сети не найдены.");
  } else {
    Serial.print("Найдено сетей: ");
    Serial.println(numberOfNetworks);
    showCurrentNetwork();
  }
  lastScanTime = millis(); // Обновляем таймер
}

// Функция для вывода выбранной сети на экран
void showCurrentNetwork() {
  if (numberOfNetworks == 0) return;

  lcd.clear();

  // Строка 1: Номер сети и её имя (SSID)
  String ssid = WiFi.SSID(currentNetworkIndex);
  if (ssid.length() > 12) {
    ssid = ssid.substring(0, 12); // Обрезаем, чтобы влез номер
  }
  lcd.setCursor(0, 0);
  lcd.print(String(currentNetworkIndex + 1) + ":" + ssid);

  // Строка 2: Сила сигнала (RSSI)
  lcd.setCursor(0, 1);
  lcd.print("Signal: ");
  lcd.print(WiFi.RSSI(currentNetworkIndex));
  lcd.print("dBm");

  // Дублируем в монитор порта
  Serial.print("Показываем сеть ");
  Serial.print(currentNetworkIndex + 1);
  Serial.print(": ");
  Serial.println(WiFi.SSID(currentNetworkIndex));
}

void setup() {
  Serial.begin(115200);

  // Настраиваем пин кнопки (включаем встроенный подтягивающий резистор INPUT_PULLUP)
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  // Включаем экран
  lcd.init();
  lcd.backlight();

  // Включаем Wi-Fi
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  delay(100);

  // Делаем первое сканирование при старте
  scanWiFi();
}

void loop() {
  // 1. Проверяем нажатие кнопки (при INPUT_PULLUP нажатая кнопка дает LOW)
  if (digitalRead(BUTTON_PIN) == LOW) {
    delay(50); // Защита от дребезга контактов (дебаунс)
    if (digitalRead(BUTTON_PIN) == LOW) {

      if (numberOfNetworks > 0) {
        currentNetworkIndex++; // Переходим к следующей сети

        // Если дошли до конца списка, возвращаемся к первой сети
        if (currentNetworkIndex >= numberOfNetworks) {
          currentNetworkIndex = 0;
        }

        showCurrentNetwork(); // Обновляем экран
      }

      // Ждем, пока пользователь отпустит кнопку, чтобы список не листал слишком быстро
      while (digitalRead(BUTTON_PIN) == LOW) {
        delay(10);
      }
    }
  }

  // 2. Автоматически обновляем список сетей каждые 30 секунд
  if (millis() - lastScanTime >= SCAN_INTERVAL) {
    scanWiFi();
  }
}
